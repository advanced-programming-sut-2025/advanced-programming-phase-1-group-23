package controller;

import model.Basics.Result;

public class TransactionController extends ControllersController {
    public Result showProducts(String command) {
        return null;
    }

    public Result showAvaliableProducts(String command) {
        return null;
    }

    public Result shopping(String command) {
        return null;
    }

    public Result cheatCategoryAddDollars(String command) {
        return null;
    }

    public Result sellProduct(String command) {
        return null;
    }

    public Result startTrade(String command) {
        return null;
    }

    public Result tradeList(String command) {
        return null;
    }

    public Result trade(String command) {
        return null;
    }

    public Result responseAccept(String command) {
        return null;
    }

    public Result responseReject(String Command) {
        return null;
    }

    public Result responseHistory(String Command) {
        return null;
    }

}
