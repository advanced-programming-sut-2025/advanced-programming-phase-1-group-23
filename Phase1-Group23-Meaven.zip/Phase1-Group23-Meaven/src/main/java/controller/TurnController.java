package controller;

import model.Basics.*;
import model.Command;
import model.Maps.Farm;
import model.Repo.GameRepo;
import model.Repo.UserRepo;
import model.Resualt;
import model.enums.GameMenuCommands;
import model.enums.Menus;
import view.AppView;
import view.PlayGame;

import java.util.*;

public class TurnController extends ControllersController {
    public static boolean isWaitingForChoosingMap = false;

    public static Resualt handleNewGame(Command request) {
        String[] usernames = request.body.get("users").split("\\s+");

        ArrayList<Player> players = new ArrayList<>();
        User loggedInUser = App.getLoggedInUser();
        players.add(new Player(loggedInUser));

        for (int i = 1; i < usernames.length; i++) {
            String username = usernames[i];
            User user = UserRepo.findUserByUsername(username);

            if (user == null) return new Resualt(false, "User " + username + " not found.");
            if (user.equals(loggedInUser)) return new Resualt(false, "You can't add yourself.");
            if (user.getCurrentGame() != null) return new Resualt(false, "Player " + username + " is already in a game.");

            players.add(new Player(user));
        }

        Game game = new Game(players, players.get(0));
        players.forEach(p -> p.getUser().setCurrentGame(game));
        isWaitingForChoosingMap = true;

        game.setFarm(Farm.makeNPCFarm());

        return new Resualt(true,
                "Game created successfully. Players must now choose a map.\n" +
                        "Use 'game map <map_number>' to choose between Map 1 and 2."
        );
    }

    public static Resualt handleMapSelection(Command request) {
        User user = App.getLoggedInUser();
        Game game = user.getCurrentGame();
        Player player = game.getCurrentPlayer();

        int mapNumber;
        try {
            mapNumber = Integer.parseInt(request.body.get("mapNumber"));
        } catch (NumberFormatException e) {
            return new Resualt(false, "Invalid map number format.");
        }

        if (mapNumber != 1 && mapNumber != 2) {
            return new Resualt(false, "Map number must be 1 or 2.");
        }

        Farm farm = Farm.makeFarm(mapNumber);
        game.getMap().addFarm(farm);
        player.setFarm(farm);

        boolean allSelected = game.cycleToNextPlayer();
        if (allSelected) {
            isWaitingForChoosingMap = false;

            List<User> users = game.getPlayers().stream()
                    .map(Player::getUser)
                    .toList();
            // GameRepo.saveGame(game, users); // Uncomment if needed

            return new Resualt(true,
                    player.getUser().getUsername() + " has chosen their farm.\n" +
                            "All farms selected! Game successfully created!"
            );
        }

        return new Resualt(true, player.getUser().getUsername() + " has chosen their farm.");
    }

    public static Resualt handleLoadGame(Command request) {
        User user = App.getLoggedInUser();
        if (user.getCurrentGame() == null) {
            Command newGameCmd = new Command("game new -u Sobhan1 Sobhan2 Sobhan3");
            newGameCmd.body.put("users", GameMenuCommands.GAME_NEW.getGroup("game new -u Sobhan1 Sobhan2 Sobhan3", "users"));
            handleNewGame(newGameCmd);
        }

        Game game = user.getCurrentGame();
        List<Player> players = game.getPlayers();

        Player current = players.getFirst();
        Player loader = null;

        for (Player player : players) {
            User updatedUser = UserRepo.findUserByUsername(player.getUser().getUsername());
            player.setUser(updatedUser);

            if (updatedUser.equals(user)) {
                game.setCurrentPlayer(player);
                loader = player;
            }
        }

        game.setGameOngoing(true);

        if (loader != null) {
            int index = players.indexOf(loader);
            players.set(index, current);
            players.set(0, loader);
        }

        game.setGameThread(new PlayGame(game));
        game.getGameThread().keepRunning = true;
        game.getGameThread().start();

        GameRepo.saveGame(game);

        return new Resualt(true,
                "Game successfully loaded.\nWelcome back, " + user.getUsername() + "!"
        );
    }

    public static Resualt handleExitGame(Command request) {
        User user = App.getLoggedInUser();
        Game game = user.getCurrentGame();

        if (!game.getCurrentPlayer().getUser().equals(user)) {
            return new Resualt(false,
                    "Only the current player can exit the game."
            );
        }

        game.setGameOngoing(false);
        game.getGameThread().keepRunning = false;
        game.hasTurnCycleFinished = false;

        GameRepo.saveGame(game);
        App.setCurrentMenu(Menus.GameMenu);

        return new Resualt(true,
                "Game saved successfully. Goodbye " + user.getUsername() + "!"
        );
    }

    public static Resualt handleForceDeleteGame(Command request) {
        User user = App.getLoggedInUser();
        Game game = user.getCurrentGame();

        if (!game.getCurrentPlayer().getUser().equals(user)) {
            return new Resualt(false, "Only the current player can delete the game.");
        }

        System.out.println("Deletion initiated. Awaiting votes...");

        do {
            Player voter = game.getCurrentPlayer();
            System.out.print("Confirmation from " + voter.getUser().getUsername() + " (Y/n): ");
            String input = AppView.scanner.nextLine().trim();

            if (!input.equalsIgnoreCase("Y")) {
                game.setCurrentPlayer(game.findPlayerByUser(user));
                return new Resualt(true, "Vote rejected. Game deletion canceled.");
            }
            System.out.println("Vote recorded. Moving to next player...");
        } while (!game.cycleToNextPlayer());

        terminateGame(game, user);
        return new Resualt(true, "Game deleted successfully. Returning to menu.");
    }

    private static void terminateGame(Game game, User user) {
        game.getGameThread().keepRunning = false;
        game.setGameOngoing(false);
        user.setCurrentGame(null);
        user.getGames().remove(game);
        GameRepo.removeGame(game);
    }

    public static Resualt handleNextTurn(Command request) {
        User user = App.getLoggedInUser();
        Game game = user.getCurrentGame();

        game.getCurrentPlayer().setUsedEnergyInTurn(0);

        StringBuilder response = new StringBuilder();
        do {
            Player current = game.getCurrentPlayer();
            int index = game.getPlayers().indexOf(current);

            if (index == game.getPlayers().size() - 1) {
                game.setCurrentPlayer(game.getPlayers().getFirst());
                game.hasTurnCycleFinished = true;
            } else {
                game.setCurrentPlayer(game.getPlayers().get(index + 1));
            }

            if (game.getCurrentPlayer().isFainted()) {
                response.append("Player ")
                        .append(game.getCurrentPlayer().getUser().getUsername())
                        .append(" was fainted and skipped.\n");
            }
        } while (game.getCurrentPlayer().isFainted());

        Player nextPlayer = game.getCurrentPlayer();
        response.append("It is now ").append(nextPlayer.getUser().getUsername()).append("'s turn!");

        // Add inbox, gifts, and marriage requests
        if (!nextPlayer.getInbox().isEmpty()) {
            response.append("\nInbox:\n")
                    .append(FriendshipController.showInbox(nextPlayer).getAnswer());
        }
        if (!nextPlayer.getReceivedGifts().isEmpty()) {
            response.append("\nReceived Gifts:\n")
                    .append(FriendshipController.showReceivedGifts(nextPlayer).getAnswer());
        }
        if (!nextPlayer.getMarriageRequests().isEmpty()) {
            response.append("\nMarriage Requests:\n")
                    .append(FriendshipController.showMarriageRequests(nextPlayer).getAnswer());
        }

        return new Resualt(true, response.toString());
    }
}
