package controller;

import model.Basics.App;
import model.Basics.Result;
import model.Command;
import model.Resualt;
import model.enums.Menus;

public class ControllersController {

    public static Resualt getMenu(Command command) {
        String targetMenu = command.body.get("menuName");
        Menus current = App.getCurrentMenu();

        if (current == Menus.LoginMenu) {
            return failure("^_^ Please log in before accessing the menus");
        }

        switch (current) {
            case MainMenu:
                return handleMainMenu(targetMenu);
            case GameMenu:
            case ProfileMenu:
                return handleSubMenu(current, targetMenu);
            default:
                return failure("SORRY sorry!");
        }
    }

    private static Resualt handleMainMenu(String targetMenu) {
        switch (targetMenu.toLowerCase()) {
            case "gamemenu":
                App.setCurrentMenu(Menus.GameMenu);
                return success("^_^ Taking you to the game menu");
            case "profilemenu":
                App.setCurrentMenu(Menus.ProfileMenu);
                return success("^_^ Taking you to the profile menu");
            default:
                return failure("-_- Invalid menu");
        }
    }

    private static Resualt handleSubMenu(Menus current, String targetMenu) {
        if (targetMenu.equalsIgnoreCase("MainMenu")) {
            App.setCurrentMenu(Menus.MainMenu);
            String message = current == Menus.GameMenu ?
                    "^_^ Taking you to the main menu" :
                    "^_^ Back to the main menu we go";
            return success(message);
        }
        return failure("-_- Invalid menu");
    }

    public static Resualt exit(Command command) {
        Menus current = App.getCurrentMenu();
        switch (current) {
            case ProfileMenu:
            case GameMenu:
                App.setCurrentMenu(Menus.MainMenu);
                return success("^_^ Exiting to Main Menu");
            case MainMenu:
            case LoginMenu:
                App.setCurrentMenu(Menus.ExitMenu);
                return success("^_^ Exiting app");
            default:
                return failure("SORRY sorry!");
        }
    }

    public static Resualt handleShowMenu(Command request) {
        return success(App.getCurrentMenu().toString());
    }

    // Helpers
    private static Resualt success(String message) {
        return new Resualt(true, message);
    }

    private static Resualt failure(String message) {
        return new Resualt(false, message);
    }
}
