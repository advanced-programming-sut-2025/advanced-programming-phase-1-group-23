package controller;

import model.Basics.*;
import model.Command;
import model.Maps.*;
import model.Objects.Inventory;
import model.Objects.Tool;
import model.Repo.GameRepo;
import model.Resualt;
import model.enums.Ingredients;
import model.enums.Weather;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class GameController extends ControllersController {


    public static Resualt handleTimeQuery(Command request) {
        return safely(() -> App.getLoggedInUser().getCurrentGame().getDate().toLocalTime().toString());
    }

    public static Resualt handleDateQuery(Command request) {
        return safely(() -> App.getLoggedInUser().getCurrentGame().getDate().toLocalDate().toString());
    }

    public static Resualt handleDatetimeQuery(Command request) {
        return safely(() -> {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            return App.getLoggedInUser().getCurrentGame().getDate().format(formatter);
        });
    }

    public static Resualt handleDayOfWeekQuery(Command request) {
        return safely(() -> App.getLoggedInUser().getCurrentGame().getDate().getDayOfWeek().toString().toLowerCase());
    }



    public static Resualt handleCheatAdvanceTime(Command request) {
        try {
            int hours = Integer.parseInt(request.body.get("X"));
            Game game = App.getLoggedInUser().getCurrentGame();
            LocalDateTime current = game.getDate();

            int totalDays = hours / 24;
            int remainingHours = hours % 24;
            int months = totalDays / 28;
            int days = totalDays % 28;

            int newHour = current.getHour() + remainingHours;
            if (newHour > 22) {
                days++;
                newHour = 9;  // forced morning reset
            }

            LocalDateTime newDate = current.plusMonths(months).plusDays(days).withHour(newHour);
            boolean newDay = newDate.toLocalDate().isAfter(current.toLocalDate());

            game.setDate(newDate);
            game.checkSeasonChange();
            if (newDay) game.newDayBackgroundChecks();

            return new Resualt(true, "Date and time set successfully.");
        } catch (Exception e) {
            return new Resualt(false, "Invalid input for advancing time.");
        }
    }

    public static Resualt handleCheatAdvanceDate(Command request) {
        try {
            int days = Integer.parseInt(request.body.get("X"));
            Game game = App.getLoggedInUser().getCurrentGame();
            LocalDateTime newDate = game.getDate().plusDays(days);
            boolean newDay = newDate.toLocalDate().isAfter(game.getDate().toLocalDate());

            game.setDate(newDate);
            if (newDay) game.newDayBackgroundChecks();
            game.checkSeasonChange();

            return new Resualt(true, "Date set successfully.");
        } catch (Exception e) {
            return new Resualt(false, "Invalid input for advancing date.");
        }
    }


    public static Resualt handleWeatherQuery(Command request) {
        return new Resualt(true, App.getLoggedInUser().getCurrentGame().getWeatherToday().toString());
    }

    public static Resualt handleWeatherForecastQuery(Command request) {
        return new Resualt(true, "Tomorrow's weather forecast is: " +
                App.getLoggedInUser().getCurrentGame().getWeatherTomorrow());
    }

    public static Resualt handleSetWeatherCheat(Command request) {
        String type = request.body.get("Type");
        Weather weather = Weather.getWeatherByName(type);
        if (weather == null) {
            return new Resualt(false, "Weather type is invalid.");
        }
        App.getLoggedInUser().getCurrentGame().setWeatherTomorrow(weather);
        return new Resualt(true, "Tomorrow's weather set successfully.");
    }


    public static Resualt handleGreenhouseBuilding(Command request) {
        Game game = App.getLoggedInUser().getCurrentGame();
        Player player = game.getCurrentPlayer();
        Farm farm = player.getFarm();

        Tile centerTile = Farm.getCellByCoordinate(25, 4, farm.getCells());
        if (centerTile.getObjectOnCell() instanceof Water)
            return new Resualt(false, "Greenhouse already built.");

        if (player.getMoney() < 1000)
            return new Resualt(false, "You don't have enough money.");

        if (player.getInventory().getIngredients().getOrDefault(Ingredients.WOOD, 0) < 500)
            return new Resualt(false, "You don't have enough wood.");

        for (int i = 23; i < 28; i++) {
            for (int j = 4; j < 10; j++) {
                Farm.getCellByCoordinate(i, j, farm.getCells()).setObjectOnCell(new NothingInTile());
            }
        }

        Farm.getCellByCoordinate(25, 10, farm.getCells()).setObjectOnCell(new NothingInTile());
        Farm.getCellByCoordinate(25, 4, farm.getCells()).setObjectOnCell(new Water());

        return new Resualt(true, "Greenhouse built successfully.");
    }


    public static Resualt handleCheatThor(Command request) {
        try {
            int x = Integer.parseInt(request.body.get("x"));
            int y = Integer.parseInt(request.body.get("y"));

            if (x < 0 || x >= 75 || y < 0 || y >= 50)
                return new Resualt(false, "Coordinates out of bounds.");

            Game game = App.getLoggedInUser().getCurrentGame();
            game.getCurrentPlayer().getCurrentFarm(game).strikeLightning(x, y, game.getDate());

            return new Resualt(true, "Lightning summoned at target coordinates.");
        } catch (Exception e) {
            return new Resualt(false, "Invalid coordinates.");
        }
    }


    public static Resualt handleSeasonQuery(Command request) {
        return new Resualt(true, App.getLoggedInUser().getCurrentGame().getSeason().toString());
    }


    private static Resualt safely(Supplier<String> supplier) {
        try {
            return new Resualt(true, supplier.get());
        } catch (Exception e) {
            return new Resualt(false, "An error occurred: " + e.getMessage());
        }
    }

    private interface Supplier<T> {
        T get() throws Exception;
    }
}
