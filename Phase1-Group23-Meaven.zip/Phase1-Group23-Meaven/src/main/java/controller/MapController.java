package controller;

import model.Basics.*;
import model.Command;
import model.Maps.*;
import model.NPC.NPC;
import model.Objects.Shop;
import model.Repo.GameRepo;
import model.Resualt;
import view.AppView;

import java.util.*;

public class MapController {

    private static Position getEmptyCoordinate(Player player, ArrayList<Tile> cells) {
        for (int i = 60; i >= 0; i--) {
            for (int j = 8; j <= 40; j++) {
                Cell cell = Farm.getCellByCoordinate(i, j, cells);
                if (cell != null && cell.getObjectOnCell().canWalk &&
                        (player == null || !player.getPosition().equals(new Position(i, j)))) {
                    return new Position(i, j);
                }
            }
        }
        return null;
    }

    public static Resualt walkHome(Command request) {
        Game game = App.getLoggedInUser().getCurrentGame();
        Player player = game.getCurrentPlayer();
        Farm farm = player.getFarm();

        player.setInVillage(false);
        Position newPosition = getEmptyCoordinate(player, farm.getCells());

        if (newPosition == null) {
            GameRepo.saveGame(game);
            return new Resualt(false, "No empty cell found.");
        }

        player.setPosition(newPosition);
        return new Resualt(true, "You are in home.");
    }

    public static Resualt handleAddCoords(Command request) {
        Player player = App.getLoggedInUser().getCurrentGame().getCurrentPlayer();
        Position current = player.getPosition();
        int newX = current.getX() + Integer.parseInt(request.body.get("x"));
        int newY = current.getY() + Integer.parseInt(request.body.get("y"));

        Command newCommand = new Command(request.command);
        newCommand.body.put("x", String.valueOf(newX));
        newCommand.body.put("y", String.valueOf(newY));

        return handleWalking(newCommand);
    }

    public static Resualt handleWalking(Command request) {
        Game game = App.getLoggedInUser().getCurrentGame();
        Player player = game.getCurrentPlayer();

        if (player.isInVillage()) {
            return new Resualt(false, "You can't walk in the village.");
        }

        int x = Integer.parseInt(request.body.get("x"));
        int y = Integer.parseInt(request.body.get("y"));

        Farm farm = player.getCurrentFarm(game);
        Position currentPos = player.getPosition();

        Cell src = new Cell(farm.findCellByCoordinate(currentPos.getX(), currentPos.getY()));
        Cell destCell = farm.findCellByCoordinate(x, y);

        if (destCell == null || !destCell.getObjectOnCell().canWalk) {
            return new Resualt(false, "Destination is not valid.");
        }

        Cell dest = GoTrack.pathBFS(src, new Cell(destCell.clone()), farm.getCells());
        dest.setEnergy();
        double energyCost = dest.energy / 20.0;

        System.out.printf("⚡Your energy: %.2f\nPath energy cost: %.2f\nMove? (Y/N): ", player.getEnergy(), energyCost);
        String answer = AppView.scanner.nextLine();

        if (!answer.equalsIgnoreCase("Y")) {
            farm.initialCells();
            return new Resualt(false, "Movement aborted.");
        }

        // Backtrack and compute path
        ArrayList<Cell> path = new ArrayList<>();
        while (dest != null) {
            if (dest.prev != null)
                dest.energy -= dest.prev.energy;
            dest.energy /= 20;
            path.add(dest);
            dest = dest.prev;
        }
        Collections.reverse(path);

        for (Cell c : path) {
            double energy = c.energy;

            if (energy > player.getEnergy()) {
                player.setFainted(true);
                player.setEnergy(player.getEnergy() - energy);
                TurnController.handleNextTurn(null);
                GameRepo.saveGame(game);
                return new Resualt(false, "You have fainted.");
            }

            if (energy + player.getUsedEnergyInTurn() > 50) {
                GameRepo.saveGame(game);
                return new Resualt(false, "Too much energy used in this turn.");
            }

            player.setPosition(c.getCoordinate());
            player.setEnergy(player.getEnergy() - energy);
            player.setUsedEnergyInTurn(player.getUsedEnergyInTurn() + energy);
        }

        return new Resualt(true, "Successfully moved to the destination.");
    }

    public static Resualt showFarm(Command request) {
        Game game = App.getLoggedInUser().getCurrentGame();
        Farm farm = game.getCurrentPlayer().getCurrentFarm(game);

        int x = Integer.parseInt(request.body.get("x"));
        int y = Integer.parseInt(request.body.get("y"));
        int size = Integer.parseInt(request.body.get("size"));

        farm.showFarm(x, y, size, game);
        return new Resualt(true, "");
    }

    public static Resualt showFullFarm(Command request) {
        Farm farm = App.getLoggedInUser().getCurrentGame().getCurrentPlayer().getFarm();
        farm.showEntireFarm();
        return new Resualt(true, "");
    }

    public static Resualt handleMapHelp(Command request) {
        String helpMessage = """
                Spot the blue 'O' - that's your pixelated alter ego!
                Everything else? Just their first initial wearing their favorite color:
                
                \u001B[94m ^_^ Legend: \u001B[0m
                \u001B[35m s: *ForagingMineral* \u001B[0m
                \u001B[34m w: *Water* \u001B[0m
                \u001B[36m #: *Stone* \u001B[0m
                \u001B[32m t: *Tree & Plant* \u001B[0m
                \u001B[33m .: *Empty* \u001B[0m
                \u001B[31m b: *Buildings* \u001B[0m
                \u001B[95m f: *ForagingCrop* \u001B[0m
                """;
        return new Resualt(true, helpMessage);
    }

    public static Resualt goToVillage(Command request) {
        Game game = App.getLoggedInUser().getCurrentGame();
        Player player = game.getCurrentPlayer();

        if (player.isInVillage()) {
            player.setInVillage(false);
            player.setPosition(player.getLastPosition());
            return new Resualt(true, "You are now in the farm.");
        } else {
            player.setInVillage(true);
            return new Resualt(true, "You are in the village.");
        }
    }

    public static Resualt walkInVillage(Command request) {
        int x = Integer.parseInt(request.body.get("x"));
        int y = Integer.parseInt(request.body.get("y"));

        Game game = App.getLoggedInUser().getCurrentGame();
        Player player = game.getCurrentPlayer();

        if (!player.isInVillage()) {
            return new Resualt(false, "You aren't in the village.");
        }

        Position destination = new Position(x, y);
        for (NPC npc : game.getNpcs()) {
            if (npc.getPosition().equals(destination)) {
                return new Resualt(false, "Destination is occupied.");
            }
        }

        player.setCurrentShop(null);
        for (model.Maps.Building building : game.getFarm().getBuildings()) {
            if (building instanceof Shop shop &&
                    shop.getTileByCoordinate(destination) != null) {
                int hour = game.getDate().getHour();
                if (hour < shop.getStartingTime() || hour > shop.getFinishingTime()) {
                    return new Resualt(false, "Shop is closed.");
                }
                player.setCurrentShop(shop);
            }
        }

        player.setPosition(destination);
        return new Resualt(true, "Moved to the destination.");
    }
}
