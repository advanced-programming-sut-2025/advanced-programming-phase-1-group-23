package controller;

import model.Basics.Result;

public class LogoutController extends ControllersController {
    public Result logout(String command){
        return null;
    }
}
