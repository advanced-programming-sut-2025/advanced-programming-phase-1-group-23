package model.Basics;

public record Result(boolean isSuccess, String message) {
}
