package model;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

public class Authorization {

    private static final String SPECIAL_CHARACTERS = "?><,\"';:\\\\/|\\]\\[}{+=)(@*&^%$#!";

    private static int countChar(char ch, String input) {
        return input.length() - input.replace(String.valueOf(ch), "").length();
    }


    public static boolean isPasswordFormatValid(String password) {
        return password != null && password.matches("[a-zA-Z\\d" + SPECIAL_CHARACTERS + "]+");
    }


    public static String checkPasswordStrength(String password) {
        if (password == null || password.isEmpty()) {
            return "Even ghosts need passwords! Please type something!";
        }

        if (password.length() < 8) {
            return "Your password is shorter than a TikTok attention span!";
        }

        boolean hasLower = false, hasUpper = false, hasDigit = false, hasSpecial = false;

        for (char ch : password.toCharArray()) {
            if (Character.isLowerCase(ch)) hasLower = true;
            else if (Character.isUpperCase(ch)) hasUpper = true;
            else if (Character.isDigit(ch)) hasDigit = true;
            else if (SPECIAL_CHARACTERS.indexOf(ch) != -1) hasSpecial = true;
        }

        if (!hasLower) return "No lowercase? ARE YOU SHOUTING AT ME?";
        if (!hasUpper) return "Where's the uppercase? We need at least one dramatic letter!";
        if (!hasDigit) return "Numbers matter! Unlike your ex's opinions...";
        if (!hasSpecial) return "Special character needed! Be more unique than your Netflix recommendations!";

        return "Approved! This password could survive a zombie apocalypse!";
    }

    public static String generateSecureRandomPassword() {
        SecureRandom random = new SecureRandom();
        int length = 8 + random.nextInt(15);

        StringBuilder sb = new StringBuilder();
        sb.append((char) ('A' + random.nextInt(26)));
        sb.append((char) ('a' + random.nextInt(26)));
        sb.append((char) ('0' + random.nextInt(10)));
        sb.append(SPECIAL_CHARACTERS.charAt(random.nextInt(SPECIAL_CHARACTERS.length())));

        while (sb.length() < length) {
            sb.append((char) ('!' + random.nextInt(93)));
        }

        return shuffle(sb.toString());
    }

    private static String shuffle(String input) {
        char[] array = input.toCharArray();
        SecureRandom rnd = new SecureRandom();
        for (int i = array.length - 1; i > 0; i--) {
            int index = rnd.nextInt(i + 1);
            char tmp = array[index];
            array[index] = array[i];
            array[i] = tmp;
        }
        return new String(array);
    }

    public static boolean isUsernameValid(String username) {
        return username != null && username.matches("^[a-zA-Z0-9-]+$");
    }

    public static boolean isEmailValid(String email) {
        if (email == null || email.isEmpty() || countChar('@', email) != 1) return false;

        String[] parts = email.split("@");
        if (parts.length != 2) return false;

        String local = parts[0], domain = parts[1];
        if (local.isEmpty() || local.matches(".*[.-]{2,}.*") || !local.matches("[a-zA-Z0-9._-]+")) return false;

        String[] domainParts = domain.split("\\.");
        if (domainParts.length < 2) return false;

        for (String part : domainParts) {
            if (part.isEmpty() || part.startsWith("-") || part.endsWith("-") || !part.matches("[a-zA-Z0-9-]+"))
                return false;
        }

        return domainParts[domainParts.length - 1].matches("[a-zA-Z]{2,}");
    }

    public static String hashPassword(String password) {
        try {
            MessageDigest sha = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = sha.digest(password.getBytes("UTF-8"));
            StringBuilder hex = new StringBuilder();
            for (byte b : hashBytes) {
                hex.append(String.format("%02x", b));
            }
            return hex.toString();
        } catch (Exception e) {
            throw new RuntimeException("Password hashing failed", e);
        }
    }

    public static boolean hasValidBoundaries(String str) {
        return str != null && str.length() > 0 &&
                Character.isLetterOrDigit(str.charAt(0)) &&
                Character.isLetterOrDigit(str.charAt(str.length() - 1));
    }
}
