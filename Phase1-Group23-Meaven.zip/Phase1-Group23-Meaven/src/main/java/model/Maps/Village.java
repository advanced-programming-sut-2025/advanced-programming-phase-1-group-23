package model.Maps;

import dev.morphia.annotations.Embedded;

@Embedded
public class Village {
}
