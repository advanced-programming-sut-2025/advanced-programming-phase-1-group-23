package model.Seasons;


import model.Maps.Position;

public class Weather {
    public String weather;

    public Weather(String weather) {
        this.weather = weather;
    }

    public Position LocationOfLightning(){
        Position result = null;
        return result;
    }
}