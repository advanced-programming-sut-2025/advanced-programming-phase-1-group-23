package view;

import controller.LogoutController;
import controller.NPCController;

import java.util.Scanner;

public class HomeMenu implements AppMenu{
   // private NPCController NPCcontroller = new NPCController();
    private LogoutController LogoutController = new LogoutController();
    public void check(Scanner scanner){

    }
}
