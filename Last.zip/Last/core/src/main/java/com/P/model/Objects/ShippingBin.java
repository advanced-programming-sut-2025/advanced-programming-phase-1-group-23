package com.P.model.Objects;

import com.P.model.Naturals.Objectss;

public class ShippingBin implements Objectss {
    private int totalMoney;

    public ShippingBin() {
        this.totalMoney = 0;
    }

    public int getTotalMoney() {
        return totalMoney;
    }

    public void setTotalMoney(int totalMoney) {
        this.totalMoney = totalMoney;
    }

    public void addTotalMoney(int amount) {
        this.totalMoney += amount;
    }
}
