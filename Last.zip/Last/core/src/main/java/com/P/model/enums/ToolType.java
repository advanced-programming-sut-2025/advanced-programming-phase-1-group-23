package com.P.model.enums;

public enum ToolType {
    Hoe,
    Axe,
    Scythe,
    Pickaxe,
    Scissors,
    WateringCan,
    MilkingCan,
    TrashCan,
    FishingRod;
}
