package com.P.model.Seasons;

public class TimeAndDate {
    private int hour;
    private int day;
    private final String[] daysName = {"Saturday", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"};

    public TimeAndDate(int hour, int day) {
        this.hour = hour;
        this.day = day;
    }

    public void increaseHour() {
    }

    public void increaseDayAndSeason() {
    }

}
