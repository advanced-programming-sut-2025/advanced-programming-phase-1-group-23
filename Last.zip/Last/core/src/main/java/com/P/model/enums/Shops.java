package com.P.model.enums;

public enum Shops {
    BlackSmith,
    JojaMart,
    PierreGeneralStore,
    CarpenterShop,
    FishShop,
    MarnieRanch,
    TheStardropSaloon;
}
