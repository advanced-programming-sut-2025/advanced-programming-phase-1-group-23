package com.P.controller;

import com.P.model.Basics.Result;

public class LivestockController extends ControllersController {
    public Result buyAnimals(String command) {
        return null;
    }

    public Result animals(String command) {
        return null;
    }

    public Result category(String command) {
        return null;
    }

    public Result feed(String command) {
        return null;
    }

    public Result product(String command) {
        return null;
    }

    public Result ProductionCollection(String command) {
        return null;
    }

    public Result sellAnimals(String command) {
        return null;
    }

    public Result fishing(String command) {
        return null;
    }
}
