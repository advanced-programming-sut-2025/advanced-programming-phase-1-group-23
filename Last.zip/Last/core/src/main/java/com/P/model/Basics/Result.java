package com.P.model.Basics;

public record Result(boolean isSuccess, String message) {
}
