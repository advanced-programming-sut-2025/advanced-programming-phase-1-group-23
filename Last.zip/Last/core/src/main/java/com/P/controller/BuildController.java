package com.P.controller;

import com.P.model.Basics.Result;

public class BuildController extends ControllersController {
    public Result greenHouseBuilding(String command) {
        return null;
    }

    public Result toolUse(String command) {
        return null;
    }

    public Result buildBuilding(String command) {
        return null;
    }

    public Result buildingMachine(String command) {
        return null;
    }
}
