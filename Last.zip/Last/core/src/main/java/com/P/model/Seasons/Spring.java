package com.P.model.Seasons;

public class Spring implements AppSeason {
    public void WeatherForecast() {

    }
    public void Fishing() {

    }
}
