package com.P.view;

import java.util.Scanner;

public class AvatarMenu implements AppMenu {

    public void check(Scanner scanner) {

    }
}
