package com.P.model.Seasons;

public class Autumn implements AppSeason {
    public void WeatherForecast() {

    }
    public void Fishing() {

    }
}
