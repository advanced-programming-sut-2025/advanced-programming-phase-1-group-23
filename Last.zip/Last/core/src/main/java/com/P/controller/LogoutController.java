package com.P.controller;

import com.P.model.Basics.Result;

public class LogoutController extends ControllersController {
    public Result logout(String command){
        return null;
    }
}
