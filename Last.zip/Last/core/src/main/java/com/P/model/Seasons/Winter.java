package com.P.model.Seasons;

public class Winter implements AppSeason {
    public void WeatherForecast() {

    }
    public void Fishing() {

    }
}
