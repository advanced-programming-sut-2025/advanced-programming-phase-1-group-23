package com.P.model.Basics;

public record ProcessingRecord(String description, double energy) {
}
