package com.P.model.Maps;

import dev.morphia.annotations.Embedded;

@Embedded
public class FodderCrop extends Objects{
    public FodderCrop() {
        super(true,"bright purple","fodderCrop");
    }
}
