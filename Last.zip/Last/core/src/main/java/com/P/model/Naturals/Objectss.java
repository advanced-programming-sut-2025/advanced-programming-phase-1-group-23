package com.P.model.Naturals;

public interface Objectss {
}
