Hello There!

Thank you for your visit. We really appreciate you for downloading and using our font.

Please remember that, this version is only permitted for Personal Use, using for commercial needs/ projects is not allowed for any reason!

Your personal projects with commission or profit is not allowed!

If you want to donate to this font, we really appreciate it.

For Full Version and Commercial Licenses, please purchase the license to: https://fikryalstudio.com/product/soul-collections-handbrush-script-font/

For more information please contact my email: mfikryalif@gmail.com or visit: https://fikryalstudio.com


NOTE:

Using this version for commercial needs/ projects without purchasing our licenses, whether for individuals, printing businesses, brands, agencies, or companies, must follow our terms and conditions of license. You must be willing to pay our license charges and penalty fees for violating of the license use.

www.fikryalstudio.com