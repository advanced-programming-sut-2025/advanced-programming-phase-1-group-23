package model.Naturals;

public interface Objectss {
}
