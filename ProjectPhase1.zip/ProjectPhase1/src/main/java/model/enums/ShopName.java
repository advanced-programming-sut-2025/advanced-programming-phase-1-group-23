package model.enums;

public enum ShopName {
    BlackSmith,
    MarnieRanch,
    StardropSaloon,
    CarpenterShop,
    JojaMart,
    PierreGeneralStore,
    FishShop;
}
