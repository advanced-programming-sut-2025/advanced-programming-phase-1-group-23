package model.enums;

public enum IngredientsTypes {
    dairy,
    junk,
    food,
    fruit,
    vegetable,
    fish,
    ore,
    mineral,
    craftedObjects,
    ;
}
