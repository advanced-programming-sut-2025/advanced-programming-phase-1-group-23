package model.enums;

public enum ToolLevel {
    Initial,
    Cooper,
    Iron,
    Gold,
    Iridium,
    Learning,
    Bambou,
    FiberGlass,
    ;
}
