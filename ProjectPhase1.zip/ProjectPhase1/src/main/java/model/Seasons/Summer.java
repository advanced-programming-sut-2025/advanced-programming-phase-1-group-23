package model.Seasons;

public class Summer implements AppSeason {
    public void WeatherForecast() {

    }
    public void Fishing() {

    }
}
