package model.Seasons;

public interface AppSeason {
    public abstract void WeatherForecast();
    public abstract void Fishing();
}
