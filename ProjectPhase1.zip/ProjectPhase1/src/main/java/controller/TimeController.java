package controller;

import model.Basics.Result;

public class TimeController extends ControllersController {
    public Result time(String command) {
        return null;
    }

    public Result date(String command) {
        return null;
    }

    public Result dayOfWeek(String command) {
        return null;
    }

    public Result cheatTime(String command) {
        return null;
    }

    public Result cheatDate(String command) {
        return null;
    }

    public Result season(String command) {
        return null;
    }
}
