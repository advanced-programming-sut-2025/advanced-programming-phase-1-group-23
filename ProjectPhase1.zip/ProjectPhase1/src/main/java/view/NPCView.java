package view;

public class NPCView {

}
